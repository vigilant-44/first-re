#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
using namespace std;

struct Participant {
    string name;
    string event;
    int position;
};

// Compare function to sort by position (ascending)
bool compareByPosition(const Participant &a, const Participant &b) {
    return a.position < b.position;
}

int main() {
    int numParticipants;
    vector<Participant> allParticipants;
    vector<string> events = {
        "Shot Put Event 1", "Shot Put Event 2", "Shot Put Event 3", 
        "Shot Put Event 4", "Shot Put Event 5"
    };

    cout << "Enter number of participants: ";
    cin >> numParticipants;
    cin.ignore(); // Clear newline from buffer

    // Input participant data
    for (int i = 0; i < numParticipants; ++i) {
        Participant p;
        cout << "\nParticipant #" << i + 1 << endl;
        cout << "Name: ";
        getline(cin, p.name);
        
        cout << "Event (e.g., Shot Put Event 1): ";
        getline(cin, p.event);

        cout << "Position: ";
        cin >> p.position;
        cin.ignore();

        allParticipants.push_back(p);
    }

    // Process each event
    for (const string& eventName : events) {
        vector<Participant> eventParticipants;

        // Filter participants for this event
        for (const Participant& p : allParticipants) {
            if (p.event == eventName) {
                eventParticipants.push_back(p);
            }
        }

        // Sort based on position (ascending)
        sort(eventParticipants.begin(), eventParticipants.end(), compareByPosition);

        // Output top 3 performers
        cout << "\n?? Top Performers in " << eventName << ":\n";
        if (eventParticipants.size() == 0) {
            cout << "No participants in this event.\n";
            continue;
        }

        for (size_t i = 0; i < eventParticipants.size() && i < 3; ++i) {
            string medal;
            if (i == 0) medal = "Gold";
            else if (i == 1) medal = "Silver";
            else if (i == 2) medal = "Bronze";

            cout << medal << " - " << eventParticipants[i].name 
                 << " (Position " << eventParticipants[i].position << ")\n";
        }
    }

    return 0;
}
