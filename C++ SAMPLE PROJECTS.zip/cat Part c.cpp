#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
using namespace std;

// Struct to store participant info
struct Participant {
    string name;
    string event;
    int position;
    string medal;
};

// Comparator to sort by position
bool compareByPosition(const Participant& a, const Participant& b) {
    return a.position < b.position;
}

int main() {
    int numParticipants;
    vector<Participant> participants;
    vector<string> eventList = {
        "Shot Put Event 1", "Shot Put Event 2", "Shot Put Event 3",
        "Shot Put Event 4", "Shot Put Event 5"
    };

    cout << "Enter number of participants: ";
    cin >> numParticipants;
    cin.ignore(); // clear input buffer

    // Input all participants
    for (int i = 0; i < numParticipants; ++i) {
        Participant p;
        cout << "\nParticipant #" << i + 1 << endl;
        cout << "Name: ";
        getline(cin, p.name);

        cout << "Event (Shot Put Event 1 to 5): ";
        getline(cin, p.event);

        cout << "Position (1 for 1st, 2 for 2nd, etc.): ";
        cin >> p.position;
        cin.ignore(); // clear buffer

        p.medal = ""; // initially no medal
        participants.push_back(p);
    }

    // Process each event
    for (const string& eventName : eventList) {
        // Filter participants for this event
        vector<Participant> eventParticipants;
        for (Participant p : participants) {
            if (p.event == eventName) {
                eventParticipants.push_back(p);
            }
        }

        // Sort participants by position
        sort(eventParticipants.begin(), eventParticipants.end(), compareByPosition);

        // Assign medals to top 3
        for (size_t i = 0; i < eventParticipants.size() && i < 3; ++i) {
            if (i == 0) eventParticipants[i].medal = "Gold";
            else if (i == 1) eventParticipants[i].medal = "Silver";
            else if (i == 2) eventParticipants[i].medal = "Bronze";
        }

        // Update medals in main list
        for (Participant& mainP : participants) {
            for (const Participant& ep : eventParticipants) {
                if (mainP.name == ep.name && mainP.event == ep.event) {
                    mainP.medal = ep.medal;
                }
            }
        }
    }

    // Display results
    cout << "\n?? Medal Winners:\n";
    for (const Participant& p : participants) {
        if (p.medal != "") {
            cout << p.name << " - " << p.event 
                 << " - Position: " << p.position 
                 << " - Medal: " << p.medal << endl;
        }
    }

    return 0;
}
